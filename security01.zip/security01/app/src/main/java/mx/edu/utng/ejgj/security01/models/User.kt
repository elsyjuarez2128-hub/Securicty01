package mx.edu.utng.ejgj.security01.models

// User.kt
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class `User.kt`(
    val id: String,
    val email: String,
    val name: String,
    val token: String? = null
) : Parcelable
