package mx.edu.utng.ejgj.security01.models;

data class LoginRequest(
        val email: String,
        val password: String
)