package mx.edu.utng.ejgj.security01.network

import mx.edu.utng.ejgj.security01.models.LoginRequest
import mx.edu.utng.ejgj.security01.models.LoginResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface ApiService {

    // 🔹 Iniciar sesión: envía usuario/contraseña y devuelve token + datos de usuario
    @POST("auth/login")
    suspend fun login(
        @Body loginRequest: LoginRequest
    ): Response<LoginResponse>

    // 🔹 Validar token (requiere encabezado Authorization: Bearer <token>)
    @GET("auth/validate")
    suspend fun validateToken(
        @Header("Authorization") token: String
    ): Response<LoginResponse>

    // 🔹 Cerrar sesión
    @POST("auth/logout")
    suspend fun logout(
        @Header("Authorization") token: String
    ): Response<Unit>
}

